/**
 * @file    cpu_usage.h
 * @brief   Definitions and libraries for cpu_usage.c
 * @author  David Drtil <xdrtil03@stud.fit.vutbr.cz>
 * @date    2022-02-20
*/

#ifndef CPU_USAGE_H
#define CPU_USAGE_H

#include "hinfosvc.h"

/**
 * @brief Extract cpu informations from /proc/stat.
 * @param cpu_info Reference to array of cpu stats.
*/
void extract_cpu_info(uint64_t **cpu_info);

/**
 * @brief Obtain cpu usage / cpu load.
 * @return Cpu usage in percentage.
*/
int get_cpu_usage();

#endif
